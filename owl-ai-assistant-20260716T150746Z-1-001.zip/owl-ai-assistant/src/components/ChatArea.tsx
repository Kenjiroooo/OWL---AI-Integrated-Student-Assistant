import { useState, FormEvent } from 'react';
import { Send, PanelLeft } from 'lucide-react';
import { Message } from '../types';
import { OwlCharacter } from './OwlCharacter';

const INITIAL_MESSAGES: Message[] = [
  {
    id: '1',
    role: 'ai',
    content: 'Hello! I am OWL AI Assistant, your Universidad de Dagupan Student Assistant. How can I help you today with enrollment, finding a room, or other campus-related questions?',
    timestamp: new Date()
  }
];

const SUGGESTED_PROMPTS = [
  "Where is room 204?",
  "What is the enrollment process?",
  "Where is the UdD campus located?"
];

interface ChatAreaProps {
  toggleSidebar: () => void;
}

export function ChatArea({ toggleSidebar }: ChatAreaProps) {
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handleSend = (e?: FormEvent, presetPrompt?: string) => {
    e?.preventDefault();
    const text = presetPrompt || input;
    if (!text.trim()) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: text, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiMsg: Message = { 
        id: (Date.now() + 1).toString(), 
        role: 'ai', 
        content: 'I have received your request. I am looking up the campus information for Universidad de Dagupan to assist you.', 
        timestamp: new Date() 
      };
      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
    }, 1500);
  };

  const lastAiMessage = [...messages].reverse().find(m => m.role === 'ai');
  const showSuggestions = messages.length === 1 && !isTyping;

  return (
    <main className="flex-1 flex flex-col items-center bg-brand-surface h-full relative min-w-0">
      <div className="w-full h-full flex flex-col">
        
        {/* Header */}
        <header className="lg:hidden flex items-center justify-between p-4 border-b border-brand-primary/10 shrink-0">
          <div className="flex items-center gap-2">
            <button onClick={toggleSidebar} className="text-brand-primary/60 hover:text-brand-primary p-1 mr-1">
              <PanelLeft size={20} />
            </button>
            <div className="w-7 h-7 rounded-full bg-brand-surface flex items-center justify-center border border-brand-primary/10 overflow-hidden shrink-0">
              <OwlCharacter className="w-7 h-7 scale-[1.3] translate-y-0.5" hideShadow />
            </div>
            <span className="font-heading font-semibold text-brand-primary">OWL AI Assistant</span>
          </div>
        </header>

        {/* Scene Area */}
        <div className="flex-1 w-full bg-gradient-to-b from-blue-100 to-white relative overflow-hidden flex flex-col items-center justify-end pb-8">
          
          {/* Speech Bubble */}
          <div className="relative mb-8 max-w-md px-6 py-4 bg-white rounded-3xl rounded-br-sm shadow-xl border border-blue-100 mx-4 z-10">
            {isTyping ? (
              <div className="flex items-center justify-center gap-1.5 h-6">
                <div className="w-2 h-2 bg-brand-primary/40 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="w-2 h-2 bg-brand-primary/40 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-2 h-2 bg-brand-primary/40 rounded-full animate-bounce"></div>
              </div>
            ) : (
              <p className="text-brand-primary font-medium text-center md:text-lg leading-relaxed">
                {lastAiMessage?.content}
              </p>
            )}
            
            {/* Bubble Tail */}
            <div className="absolute -bottom-3 right-8 w-6 h-6 bg-white border-b border-r border-blue-100 transform rotate-45"></div>
          </div>

          {/* Owl Character */}
          <div className="z-0">
            <OwlCharacter isTyping={isTyping} />
          </div>

        </div>

        {/* Input Area */}
        <div className="p-4 md:p-6 w-full shrink-0 bg-white border-t border-brand-primary/10 z-20">
          <div className="max-w-[800px] mx-auto">
            {showSuggestions && (
              <div className="flex flex-wrap gap-2 mb-4 justify-center md:justify-start">
                {SUGGESTED_PROMPTS.map(prompt => (
                  <button 
                    key={prompt}
                    onClick={() => handleSend(undefined, prompt)}
                    className="px-4 py-2 rounded-full border border-brand-primary/20 bg-brand-tertiary/50 text-brand-primary text-sm hover:bg-brand-tertiary hover:border-brand-primary/40 transition-colors shrink-0 font-medium"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            )}
            <form onSubmit={handleSend} className="relative flex items-center group shadow-sm">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Message OWL AI Assistant..."
                className="w-full bg-brand-surface border border-brand-primary/20 rounded-full py-4 pl-6 pr-14 focus:outline-none focus:border-brand-secondary focus:ring-1 focus:ring-brand-secondary transition-all text-brand-neutral placeholder:text-brand-primary/40"
              />
              <button 
                type="submit"
                disabled={!input.trim()}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-3 bg-brand-secondary text-white rounded-full hover:bg-opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                <Send size={18} />
              </button>
            </form>
            <p className="text-center text-xs text-brand-neutral/50 mt-3 font-heading">
              OWL AI Assistant is an AI guide for Universidad de Dagupan students. Verify important information with the registrar.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}
