import { MessageSquare, Plus, Settings, FolderOpen, PanelLeft } from 'lucide-react';
import { OwlCharacter } from './OwlCharacter';

export function Sidebar({ toggleSidebar }: { toggleSidebar?: () => void }) {
  return (
    <aside className="w-64 border-r border-brand-primary/10 bg-brand-tertiary flex-col h-full flex shrink-0">
      <div className="p-4 border-b border-brand-primary/10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-brand-surface flex items-center justify-center border border-brand-primary/10 overflow-hidden shrink-0">
            <OwlCharacter className="w-8 h-8 scale-[1.3] translate-y-0.5" hideShadow />
          </div>
          <span className="font-heading font-semibold text-brand-primary text-lg">OWL AI Assistant</span>
        </div>
        {toggleSidebar && (
          <button onClick={toggleSidebar} className="lg:hidden text-brand-primary/60 hover:text-brand-primary p-1">
            <PanelLeft size={18} />
          </button>
        )}
      </div>
      <div className="p-4 flex-1 overflow-y-auto">
        <button className="w-full flex items-center gap-2 px-4 py-2 bg-brand-surface border border-brand-primary/10 rounded-lg text-brand-primary hover:bg-brand-primary/5 transition-colors font-heading text-sm font-semibold mb-6">
          <Plus size={16} />
          New Chat
        </button>
      </div>
      <div className="p-4 border-t border-brand-primary/10 space-y-1 shrink-0">
        <button className="w-full flex items-center gap-3 px-2 py-2 text-sm text-brand-neutral/80 hover:bg-brand-primary/5 rounded-md transition-colors">
          <FolderOpen size={16} className="text-brand-primary/50" />
          Projects
        </button>
        <button className="w-full flex items-center gap-3 px-2 py-2 text-sm text-brand-neutral/80 hover:bg-brand-primary/5 rounded-md transition-colors">
          <Settings size={16} className="text-brand-primary/50" />
          Settings
        </button>
      </div>
    </aside>
  );
}
